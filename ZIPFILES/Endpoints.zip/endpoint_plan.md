# V3.4 Endpoint Plan Summary

| Endpoint | Method | Purpose | % Done | DB? | Model Used | Code Types | License Notes | ✅ Benefits |
|----------|--------|---------|--------|------|-------------|-------------|----------------|-------------|
| `/generate-image` | POST | Create image from prompt | 100% | ✅ | SDXL | Python, diffusers | Apache 2.0 | Turns ideas into content instantly |
| `/analyze-image` | POST | Extract image metadata | 100% | ✅ optional | None (PIL) | Python, PIL | Open | Useful for tagging, organizing |
| `/generate-voice` | POST | Text-to-speech voice gen | 70% | ✅ | Bark, Tortoise | Python, TTS | Apache 2.0 | Create narrations, voiceovers |
| `/export-content` | POST | Package results into zip | 60% | ❌ | None | Python stdlib | Open | Prepares for download/posting |
| `/generate-video` | POST | Combine images + voice to video | 0% | ✅ | ffmpeg/moviepy | Python, CLI | GPL/LGPL | Build short-form content |
| `/list-styles` | GET | Return style presets | 20% | ❌ | None | Python | Open | User-friendly customization |
| `/apply-style` | POST | Apply LoRA/style to image | 10% | ✅ | LoRA, ControlNet | Python, diffusers | Varies | Stylize and personalize visuals |
| `/caption-image` | POST | Generate caption for image | 0% | ✅ | BLIP, CLIP | Python, transformers | Open | Auto-social text generation |
| `/generate-script` | POST | Create script from prompt or topic | 0% | ✅ | GPT-4, Claude | Python, OpenAI API | API Terms | Auto-story creation |
