# FastAPI app with router includes and init_db()
