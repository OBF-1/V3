# Tone, emotion, visual, etc. (tag variants)
