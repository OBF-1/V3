# SQLAlchemy model for Generation table
