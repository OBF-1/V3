# Script/narration tracking model
