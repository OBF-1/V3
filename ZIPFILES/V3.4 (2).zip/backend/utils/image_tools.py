# apply_watermark() and generate_thumbnail() with PIL
