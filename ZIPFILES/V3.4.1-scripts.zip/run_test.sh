#!/bin/bash
cd V3
python log_and_push_test.py
