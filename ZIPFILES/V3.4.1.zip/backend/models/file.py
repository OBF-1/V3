# Model for output files metadata
