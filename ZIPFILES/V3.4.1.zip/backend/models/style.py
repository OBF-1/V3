# Style name, description, model mapping
