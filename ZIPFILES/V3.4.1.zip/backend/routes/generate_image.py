# Full /generate-image route with seed, batch, style, watermark, error handling, thumbnail, replay, DB logging
