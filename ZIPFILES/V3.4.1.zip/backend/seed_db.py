# Sample rows added to each table
