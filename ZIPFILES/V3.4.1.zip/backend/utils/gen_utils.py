# generate_replay_code(), collect_generation_metadata(), is_watermark_enabled()
