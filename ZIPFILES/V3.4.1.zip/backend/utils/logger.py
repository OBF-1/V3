# log_error() function for writing to logs/errors.log
