# POST test script for /generate-image with timestamped log and error handling
