#!/bin/bash
cd V3.4
python log_and_push_test.py
